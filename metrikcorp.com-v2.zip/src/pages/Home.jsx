import React, { useEffect } from 'react';
import gsap from 'gsap';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function Home() {
  useEffect(() => {
    gsap.from('.fade-in', { opacity: 0, y: 50, duration: 1, stagger: 0.3 });
  }, []);

  return (
    <>
      <Header />
      <section className="fade-in">
        <h1>Welcome to MetrikCorp</h1>
        <p>MetrikCorp is a one-person digital studio helping businesses launch, maintain, and optimize their online presence — without the technical hassle.</p>
      </section>
      <section className="fade-in">
        <h2>What We Do</h2>
        <p>From full-stack development to server setup and website rescue, we handle everything — so you don’t have to.</p>
      </section>
      <Footer />
    </>
  );
}